﻿namespace ChargingApp.Entity;

public class PaymentGateway
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string BagAddress { get; set; }
}