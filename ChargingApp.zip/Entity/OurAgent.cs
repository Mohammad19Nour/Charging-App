﻿namespace ChargingApp.Entity;

public class OurAgent : BaseEntity
{
    public string Name { get; set; }
    public string City { get; set; }
    public string PhoneNumber { get; set; }
}