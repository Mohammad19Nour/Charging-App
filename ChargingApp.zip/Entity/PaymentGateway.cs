﻿namespace ChargingApp.Entity;

public class PaymentGateway :BaseEntity
{
    public string Name { get; set; }
    public string BagAddress { get; set; }
}