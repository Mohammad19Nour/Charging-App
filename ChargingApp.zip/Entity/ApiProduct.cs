﻿namespace ChargingApp.Entity;

public class ApiProduct
{
    public Product Product { get; set; }
    public int ApiProductId { get; set; }
}