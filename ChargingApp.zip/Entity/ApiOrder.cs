﻿namespace ChargingApp.Entity;

public class ApiOrder 
{
    public Order Order { get; set; }
    public int ApiOrderId { get; set; }
}