﻿namespace ChargingApp.Entity;

public class SliderPhoto : BaseEntity
{
    public Photo Photo { get; set; }
    public int PhotoId { get; set; }
}