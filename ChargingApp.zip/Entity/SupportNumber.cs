﻿namespace ChargingApp.Entity;

public class SupportNumber : BaseEntity
{
    public string PhoneNumber { get; set; }
}