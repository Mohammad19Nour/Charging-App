﻿using ChargingApp.DTOs;
using ChargingApp.Entity;
using ChargingApp.Errors;
using ChargingApp.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ChargingApp.Controllers;

public class AdminVipLevelController : AdminController
{
    private readonly IUnitOfWork _unitOfWork;

    public AdminVipLevelController(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    [HttpPost("add-new-vip-level")]
    public async Task<ActionResult> AddNewVipLevel([FromBody] NewVipLevel dto)
    {
        var tmp = await _unitOfWork.VipLevelRepository.CheckIfExist(dto.VipLevel);

        if (tmp || dto.VipLevel == 0)
            return BadRequest(new ApiResponse(400, "already exist"));
        
        var vip = new VIPLevel
        {
            VipLevel = dto.VipLevel,
            MinimumPurchase = dto.MinimumPurchase,
            BenefitPercent = dto.BenefitPercent
        };
        _unitOfWork.VipLevelRepository.AddVipLevel(vip);

        if (await _unitOfWork.Complete())
            return Ok(new ApiResponse(200));
        return BadRequest(new ApiResponse(400, "something went wrong"));
        
    }
}