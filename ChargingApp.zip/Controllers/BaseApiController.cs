﻿using Microsoft.AspNetCore.Mvc;

namespace ChargingApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BaseApiController : ControllerBase
{
}