namespace ChargingApp.DTOs;

public class UpdateEmailDto
{
    public string? Email { get; set; }
}
