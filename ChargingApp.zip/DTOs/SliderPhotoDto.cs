﻿namespace ChargingApp.DTOs;

public class SliderPhotoDto
{
    public int Id { get; set; }
    public string Photo { get; set; }
}