﻿namespace ChargingApp.DTOs;

public class CurrencyDto
{
    public string Name { get; set; }
    public double ValuePerDollar { get; set; }
}