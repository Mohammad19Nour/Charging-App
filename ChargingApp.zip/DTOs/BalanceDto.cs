﻿namespace ChargingApp.DTOs;

public class BalanceDto
{
    public double? Turkish { get; set; }
    public double? Syrian { get; set; }
    public double Dollar { get; set; }
}