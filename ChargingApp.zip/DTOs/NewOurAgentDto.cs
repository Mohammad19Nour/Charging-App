﻿namespace ChargingApp.DTOs;

public class NewOurAgentDto
{
    public string Name { get; set; }
    public string City { get; set; }
    public string PhoneNumber { get; set; }
}