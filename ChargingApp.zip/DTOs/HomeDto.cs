﻿namespace ChargingApp.DTOs;

public class HomeDto
{
    public ICollection<CategoryDto>? Categories { get; set; }
}