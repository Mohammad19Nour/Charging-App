﻿namespace ChargingApp.DTOs;

public class DateQueryDto
{
    public int? Year { get; set; } 
    public int? Month { get; set; }
    public int? Day { get; set; }
    
}