﻿namespace ChargingApp.DTOs;

public class RestDto
{
    public string? NewPassword { get; set; }
    public string? Code { get; set; }
}