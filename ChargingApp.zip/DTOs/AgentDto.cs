﻿namespace ChargingApp.DTOs;

public class AgentDto
{
    public int AgentId { get; set; }
    public string ArabicName { get; set; }
    public string EnglishName { get; set; }
}