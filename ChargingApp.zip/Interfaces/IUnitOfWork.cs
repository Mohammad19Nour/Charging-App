﻿namespace ChargingApp.Interfaces;

public interface IUnitOfWork
{
    
}