﻿namespace ChargingApp.DTOs;

public class ProductToUpdateDto
{
    public double SellingPrice { get; set; }
    public double BuyingPrice { get; set; }
    public string EnglishName { get; set; }
    public string ArabicName { get; set; }
}